//
//  SMKPeer.h
//  SketchMirrorKit
//
//  Created by Robin Speijer on 07-12-15.
//  Copyright © 2015 Awkward. All rights reserved.
//

@import Foundation;
#import <CoreGraphics/CGGeometry.h>

/// A Sketch Mirror application session on a specific device. This class contains all metadata about this peer like displayName, screenScale, screenSize or the modelName.
@interface SMKPeer : NSObject <NSSecureCoding, NSCopying>

- (nonnull instancetype)initWithDiscoveryInfo:(nonnull NSDictionary *)discoveryInfo;

@property (nonatomic, nonnull, readonly) NSDictionary *discoveryInfo;

/// The peer unique identifier. By default, the uuid will be set to the current device's uuid.
@property (strong, nonnull) NSUUID *uuid;

/// A displayable name for the peer's device
@property (copy, nullable) NSString *displayName;

/// The scale of the peer's screen
@property (assign) CGFloat screenScale;

/// The size of the peer's screen
@property (assign) CGSize screenSize;

/// The model name of the peer's device
@property (copy, nullable) NSString *modelName;

@end
