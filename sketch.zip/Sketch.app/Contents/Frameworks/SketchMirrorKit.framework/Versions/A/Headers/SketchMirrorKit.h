//
//  SketchMirrorKit.h
//  SketchMirrorKit
//
//  Created by Robin Speijer on 07-12-15.
//  Copyright © 2015 Awkward. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SketchMirrorKit.
FOUNDATION_EXPORT double SketchMirrorKitVersionNumber;

//! Project version string for SketchMirrorKit.
FOUNDATION_EXPORT const unsigned char SketchMirrorKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SketchMirrorKit/PublicHeader.h>

#import <SketchMirrorKit/SMKMirrorConnectionsController.h>
#import <SketchMirrorKit/SMKMirrorConnectionsControllerDelegate.h>
#import <SketchMirrorKit/SMKPeer.h>
#import <SketchMirrorKit/SMKPeerConnectionInfo.h>
